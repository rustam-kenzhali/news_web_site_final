const express = require("express")
const app = express();
const bodyParser = require("body-parser")
const mongoose = require("mongoose")
const fetch = require("node-fetch")
const path = require('path');
app.use(express.static(path.join(__dirname, 'public')))
app.use(bodyParser.urlencoded({
  extended: true
}))
app.use(bodyParser.json())

mongoose.connect("mongodb://localhost:27017/endterm", {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
app.set("view engine", "ejs")

const NewsSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  category: String,
  source: {
    type: String,
    required: true
  },
  author: {
    type: String,
    default: "Unknown"
  },
  publishedAt: {
    type: String,
    default: new Date().toLocaleDateString()
  },
  content: {
    type: String,
    required: true
  },
  url: {
    type: String,
    default: "http://placehold.it/500x350"
  }
})

const listSchema = new mongoose.Schema({
  name: String,
  news: [NewsSchema]
})


const News = new mongoose.model("News", NewsSchema)
const List = mongoose.model("List", listSchema)


async function getNews(category) {
  try {
    let newsUrl = `https://newsapi.org/v2/everything?q=${category}&sortBy=popularity&apiKey=26838ed066f94e4eb0692129dd333fd6`
    const newsResponse = await fetch(newsUrl)
    const newsData = await newsResponse.json()
    return newsData.articles;
  } catch (e) {
    return e;
  }
}


app.get("/", async function(req, res) {

  try {
    var city1 = "Almaty"
    var city2 = "Nur-Sultan"
    let citys = ["Paris", "Madrid", "New York"];

    let urlcity1 = "https://api.openweathermap.org/data/2.5/weather?q=" + city1 + "&appid=4f28487d7186d6a6c23584783728796e&units=metric"
    let urlcity2 = "https://api.openweathermap.org/data/2.5/weather?q=" + city2 + "&appid=4f28487d7186d6a6c23584783728796e&units=metric"

    const wheatherResponseAlmaty = await fetch(urlcity1)
    const weatherDataAlmaty = await wheatherResponseAlmaty.json()
    var weatherIconAlmaty = "http://openweathermap.org/img/wn/" + weatherDataAlmaty.weather[0].icon + "@2x.png"


    const wheatherResponseNurSultan = await fetch(urlcity2)
    const weatherDataNurSultan = await wheatherResponseNurSultan.json()
    var weatherIconNurSultan = "http://openweathermap.org/img/wn/" + weatherDataNurSultan.weather[0].icon + "@2x.png"

    let news = "https://newsapi.org/v2/everything?q=world&apiKey=666be19d27dd4e8682b84988bfc7c161"
    const newsResponse = await fetch(news)
    const newsData = await newsResponse.json()

    News.find(function(err, foundNews) {
      res.render("index", {
        title: "World",
        newsList: foundNews,
        weatherDataAlmaty: weatherDataAlmaty,
        weatherIconAlmaty: weatherIconAlmaty,
        weatherDataNurSultan: weatherDataNurSultan,
        weatherIconNurSultan: weatherIconNurSultan
      })
    })
  } catch (e) {
    res.send(e)
  }
})


var city
app.post('/', function(req, res) {
  const route = req.body.button;

  if (route == "submBtn") {
    city = req.body.city
    console.log(city)
    res.redirect("/moreweather")
  }


});

app.get("/moreweather", async function(req, res) {

  try {
    let CurrentWeatherURL = "https://api.weatherbit.io/v2.0/current?city=" + city + "&key=40afee027a51457db75e90d123c3f0a0"
    let WeatherURL = "http://api.weatherapi.com/v1/forecast.json?key=71771694d72d45b0bfd83602212106&q=" + city + "&days=3&aqi=no&alerts=no"

    const CurrentwheatherResponse = await fetch(CurrentWeatherURL)
    const CurrentweatherData = await CurrentwheatherResponse.json()

    const wheatherResponse = await fetch(WeatherURL)
    const weatherData = await wheatherResponse.json()

    res.render("moreweather", {
      weatherData: weatherData
    }); //link to ejs file
  } catch (e) {
    res.send(e)
  }

})


var counter = 0;

app.post("/updateAPI/:category", async function(req, res) {
  const category = req.params.category
  const news = await getNews(category)
  const num = news.length
  // const counter = 0;
  console.log(num)
  try {
    if (category == "World") {
      for (let i = counter % num; i < (counter + 5) % num; i++) {
        const newsPiece = new News({
          title: news[i].title,
          category: category,
          source: news[i].source.name,
          author: news[i].author,
          publishedAt: news[i].publishedAt,
          content: news[i].content,
          url: news[i].urlToImage
        })
        newsPiece.save()

        console.log("counter: " + counter)
      }
      counter = (counter + 5) % num
      res.redirect("/")
    } else {
      List.findOne({
        name: category
      }, async function(err, found) {
        if (!found) {
          res.redirect("/" + category)
        } else {
          for (let i = counter % num; i < (counter + 5) % num; i++) {
            const newsPiece = new News({
              title: news[i].title,
              category: category,
              source: news[i].source.name,
              author: news[i].author,
              publishedAt: news[i].publishedAt,
              content: news[i].content,
              url: news[i].urlToImage
            })
            await found.news.push(newsPiece)
            await found.save()

            console.log("counter: " + i)
          }
          counter = (counter + 5) % num
          res.redirect("/" + category)
        }
      })
    }
  } catch (e) {
    return e;
  }
})


app.get("/form", function(req, res) {
  res.render("form", {
    title: "Adding a piece of news"
  })
})

app.post("/form", function(req, res) {
  // const options = { weekday: 'long', month: 'long', day: 'numeric' }
  const category = req.body.category
  const today = new Date()

  const newsPiece = new News({
    title: req.body.title,
    category: category,
    source: req.body.source,
    author: req.body.author,
    publishedAt: today.toLocaleDateString(),
    content: req.body.content,
    url: req.body.url
  })


  ////
  if (category == "World") {
    newsPiece.save()
    res.redirect("/")

  } else {
    List.findOne({
      name: category
    }, function(err, found) {
      if (!err) {
        if (!found) {
          const listPiece = new List({
            name: category,
            news: []
          })
          console.log(listPiece)
          console.log(listPiece.save())
        }
      }
    })
    List.findOne({
      name: category
    }, function(err, found) {
      if (!found) {
        res.redirect("/" + category)
      } else {
        found.news.push(newsPiece)
        found.save()
        res.redirect("/" + category)
      }
    })
  }

  //news.save()
  //res.redirect("/")
})

app.get("/edit/:category/:id", function(req, res) {
  const id = req.params.id
  const category = req.params.category
  //const news = await News.findById(id)

  News.findOne({
    _id: id
  }, function(err, foundNews) {
    if (!err) {
      if (foundNews) {
        const news = foundNews
        res.render("edit", {
          title: "Editing a piece of news",
          news: news
        })
      } else {
        List.findOne({
          name: category
        }, function(err, foundList) {
          if (!err) {
            if (foundList) {
              //console.log(foundList)

              for (let i = 0; i < foundList.news.length; i++) {
                if (foundList.news[i]._id == id) {
                  const news = foundList.news[i]
                  //console.log(news)
                  res.render("edit", {
                    title: "Editing a piece of news",
                    news: news
                  })
                  break
                }
              }

            } else {
              res.send("no such route")
            }
          }
        })

      }
    }
  })
})





app.post("/edit/:category/:id", function(req, res) {
  const id = req.params.id
  const initCategory = req.params.category
  const changedCategory = req.body.category
  const today = new Date()
  console.log(initCategory)
  console.log(changedCategory)


  if (initCategory == changedCategory) {
    if (initCategory == "World") {
      News.findOneAndUpdate({
        _id: id
      }, req.body, {
        new: true
      }, function(err, doc) {
        if (err) {
          console.log("Error while updating article with ID " + req.params.id);
        }
        res.redirect('/');
      })
    } else {
      List.findOneAndUpdate({
        name: initCategory,
        "news._id": id
      }, {
        $set: {
          "news.$": {
            title: req.body.title,
            category: initCategory,
            source: req.body.source,
            author: req.body.author,
            publishedAt: today.toLocaleDateString(),
            content: req.body.content,
            url: req.body.url
          }
        }
      }, {
        new: true
      }, function(err, doc) {
        if (err) {
          console.log("Error while updating article with ID " + req.params.id);
        }
        res.redirect('/' + initCategory);
      })
    }




  } else {
    if (initCategory == "World") {
      News.deleteOne({
        _id: id
      }, function() {})
    } else {
      List.findOneAndUpdate({
        name: initCategory
      }, {
        $pull: {
          news: {
            _id: id
          }
        }
      }, function() {})
    }



    const newsPiece = new News({
      title: req.body.title,
      category: changedCategory,
      source: req.body.source,
      author: req.body.author,
      publishedAt: today.toLocaleDateString(),
      content: req.body.content,
      url: req.body.url
    })

    if (changedCategory == "World") {
      console.log(changedCategory)
      newsPiece.save()
      res.redirect("/")

    } else {
      List.findOne({
        name: changedCategory
      }, function(err, found) {
        if (!found) {
          res.redirect("/" + changedCategory)
        } else {
          found.news.push(newsPiece)
          found.save()
          res.redirect("/" + changedCategory)
        }
      })
    }

  }
})



//var categories = ["World", "Internet", "Technology", "Society", "Politics", "Crime", "Incidents", "Sport", "Economy"]
app.get("/:category", async function(req, res) {
  try {
    var city1 = "Almaty"
    var city2 = "Nur-Sultan"
    let citys = ["Paris", "Madrid", "New York"];

    let urlcity1 = "https://api.openweathermap.org/data/2.5/weather?q=" + city1 + "&appid=4f28487d7186d6a6c23584783728796e&units=metric"
    let urlcity2 = "https://api.openweathermap.org/data/2.5/weather?q=" + city2 + "&appid=4f28487d7186d6a6c23584783728796e&units=metric"

    const wheatherResponseAlmaty = await fetch(urlcity1)
    const weatherDataAlmaty = await wheatherResponseAlmaty.json()
    var weatherIconAlmaty = "http://openweathermap.org/img/wn/" + weatherDataAlmaty.weather[0].icon + "@2x.png"


    const wheatherResponseNurSultan = await fetch(urlcity2)
    const weatherDataNurSultan = await wheatherResponseNurSultan.json()
    var weatherIconNurSultan = "http://openweathermap.org/img/wn/" + weatherDataNurSultan.weather[0].icon + "@2x.png"

    const category = req.params.category
    List.findOne({
      name: category
    }, function(err, found) {
      if (!err) {
        if (!found) {

          res.send("no such route!")

        } else {
          res.render("index", {
            title: category,
            newsList: found.news,
            weatherDataAlmaty: weatherDataAlmaty,
            weatherIconAlmaty: weatherIconAlmaty,
            weatherDataNurSultan: weatherDataNurSultan,
            weatherIconNurSultan: weatherIconNurSultan
          })

        }
      }

    })
  } catch (e) {
    res.send(e)
  }
  //console.log(req.params.category)
})

// app.post("/create", function(req, res) {
//   const category = req.body.
//
//   List.findOne({
//     name: category
//   }, function(err, found) {
//     if (!err) {
//       if (found) {
//         res.redirect('/' + category);
//       } else {
//         const listPiece = new List({
//           name: category,
//           news: []
//         })
//         console.log(listPiece)
//         console.log(listPiece.save())
//         res.redirect('/' + category);
//
//       }
//     }
//
//   })
// })

app.post("/delete", function(req, res) {

  const category = req.body.listName
  const drop = req.body.delete

  if (category == "World") {
    News.deleteOne({
      _id: drop
    }, function() {
      res.redirect("/")
    })
  } else {
    List.findOneAndUpdate({
      name: category
    }, {
      $pull: {
        news: {
          _id: drop
        }
      }
    }, function(err, foundList) {
      if (!err) {
        res.redirect("/" + category)
      }
    })
  }
})


app.listen(5000, function() {
  console.log("localhost:5000");
})
